from tkinter import *

window = Tk()
window.title('요기가 타이틀')
window.geometry("400x100")
window.resizable(width=FALSE, height=TRUE)





window.mainloop()