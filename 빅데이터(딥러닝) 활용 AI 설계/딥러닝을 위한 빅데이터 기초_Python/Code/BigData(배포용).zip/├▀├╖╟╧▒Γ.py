import numpy as np
import random
List = [133,134,138,139,141,143,144,146,147,148,150,152,154]
print(random.sample(List, 2))